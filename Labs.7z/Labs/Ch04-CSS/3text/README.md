# Chapter 4: Working with Text properties
 
### Estimated Completion Time 
5 minutes

1. If you needed to step away or otherwise did not finish the exercise, please rename your CSS directory to CSSIncomplete, and copy solution from last chapter into your WIP directory to continue from there 

1. Continue working in `CSS` 

1. Center align the content of the header. Resize your browser and see how it adjusts. If you need a hint, or to continue, scroll down.

    ```






































    ```
    ```CSS
    header {text-align:center}
    ``` 

1. Remove the link styling
    ```






































    ```
    ```CSS
    nav ul li {text-decoration:none}
    ``` 

1. The underlining of links looks strange for navigation, turn this off. 
    ```






































      ```
      ```CSS
      nav ul li {text-decoration:none}
      ``` 
