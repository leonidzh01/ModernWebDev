# Chapter 4: Working with the Box Model

### Estimated Completion Time 
10 minutes
 

1. Add a bottom border to all articles to provide a visual separation.

1. Add padding - everywhere! it just looks better.

1. Change your nav links to look more like buttons
    * change the display to inline-block
    * give a width and height 
    * use padding to make the text more readable 
    * Make them display in a single line
