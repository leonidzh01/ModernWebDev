# Chapter 4: Working with Backgrounds

### Estimated Completion Time 
10 minutes
 
1. Visit the website: http://www.colorzilla.com/gradient-editor/

1. Play with the controls and create a gradient to be used in the header.
    * Copy the CSS properties and values and add to a CSS selector which targets the header 
    
1. Add a CSS gradient to the h2 tags of the articles 

1. Add a background color to the page.

## Bonus

1. Add an image for the links. 