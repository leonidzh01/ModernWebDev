
const hobbiesArray1 = [
    { name: 'volleyball', my1: 25 },
    { name: 'cooking', my1: 15},
    { name: 'swimming', my1: 11}
];

const hobbiesArray = [
    { name: 'volleyball', lengthInYearsAtHobby: 25 },
    { name: 'cooking', lengthInYearsAtHobby: 15},
    { name: 'swimming', lengthInYearsAtHobby: 11}
];


function printhobby(hobby) {
    console.log(` ${hobby.name} is played in ${hobby.lengthInYearsAtHobby} `)
}


for (let index = 0; index < hobbiesArray.length; index++) {

    printhobby(hobbiesArray[index]);
}
