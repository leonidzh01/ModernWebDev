let hobbiesArray = ['coding',
'testing',
'listening to music'];

function printHobbies(passedArray) {
    console.log(`I like ${passedArray.length} things`);
    for (let index = 0; index < hobbiesArray.length; index++) {
        let element = hobbiesArray[index];
        console.log('I like ' + element);
    }  
}

printHobbies(hobbiesArray); 

let obhocky={name:'hocky',duration:'20m' };
let obchess={name:'chess',duration:'2.5h' };

function printobjects(passedArray) {

    console.log(`I like ${passedArray.length} objects`);
    for (let index = 0; index < passedArray.length; index++) {
        let element = passedArray[index].name;
        console.log('I like ' + element);
    }  
}

printHobbies(obchess); 