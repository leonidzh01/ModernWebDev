let numOne = 1;
let stringOne = '1';
console.log('double ==', numOne == stringOne);
console.log('triple ===', numOne === stringOne);

const day = new Date().getDay();
console.log('Day:' + day);
if (day==4)
{
    console.log("Over the hump!");

}